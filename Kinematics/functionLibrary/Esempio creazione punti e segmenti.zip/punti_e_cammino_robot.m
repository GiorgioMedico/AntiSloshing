%%INTESTAZIONE FUNCTION
% function [punti,qc,zimmer,time,time_step] = punti_e_cammino_robot(robot)
% time_step = 0.01;


%% PUNTI DI PASSAGGIO
% CREARE UN PUNTO DA MATRICE 4X4 CAD
% punti_traiettoria = import_points('punti_e_cammino_robot.txt', 1, inf);
% punti{1}.T = punti_traiettoria(:,:,1);% matrice 4x4 da CAD
% punti{1}.XYZABC = t2xyzabc(punti_traiettoria(:,:,1));% mm e gradi
% punti{1}.ridondanza = 0;%gradi
% punti{1}.status = 0; % valore da 0-7
% punti{1}.J = inverseKinematicLBR_J(robot,punti{1}.T,punti{1}.ridondanza,punti{1}.status); %valori dei giunti

% CRERARE UN PUNTO CON TRASFORMATE
% punti{2}.T = punti{1}.T*transl(50,50,0);% matrice 4x4 da CAD
% punti{2}.XYZABC = t2xyzabc(punti_traiettoria(:,:,1));% mm e gradi
% punti{2}.ridondanza = 0;%gradi
% punti{2}.status = 0; % valore da 0-7
% punti{2}.J = inverseKinematicLBR_J(robot,punti{1}.T,punti{1}.ridondanza,punti{1}.status); %valori dei giunti


%% SEGMENTI TRAIETTORIA
% segment = 1;
% initial_point = 1;

%% middle_point = 3; % solo per CIRC_JM
% final_point = 2;
% time{segment} = 1;

%% TIPOLOGIA DI MOVIMENTI
% [qc{segment},~] = lin_JM(punti{initial_point}.T,punti{final_point}.T,time{segment},time_step,robot,punti{initial_point}.ridondanza,punti{initial_point}.status);
% [qc{segment}] = p2p_JM(punti{initial_point}.J, punti{final_point}.J, time{segment}, time_step);
% [qc{segment},~] = ns_JM(T,time,time_step,robot,status_start,redundancy_start,redundancy_stop);
% [qc{segment},~] = circ_JM(T0,T1,T2,time,time_step,robot,Redundancy,status_richiesto);
